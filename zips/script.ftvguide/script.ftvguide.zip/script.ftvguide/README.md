script.ftvguide
===============

A TV guide add on for XBMC that works with Kinkin's F.T.V and USTVNow straight out of the box.
